import { test, expect } from '@playwright/test';
import { USERS, login } from './helpers';

// Алхам 4-ийн туршилт: assertion-оо зориудаар буруу болгож trace viewer дээр хэрхэн
// харагдахыг ажиглах зорилготой ТҮР тест.
test('зориудаар унасан тест', async ({ page }) => {
  await login(page, USERS.standard.username, USERS.standard.password);
  await expect(page.getByText('Products')).toHaveText('Products1');
});
